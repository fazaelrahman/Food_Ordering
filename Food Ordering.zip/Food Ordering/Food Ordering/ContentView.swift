//
//  ContentView.swift
//  Food Ordering
//
//  Created by Faza Elrahman on 01/03/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
